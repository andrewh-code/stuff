import sys
import itertools
from operator import itemgetter

lst = [['ab', 3], ['abc', 5],['cdef', 8],['dg', 2],['e', 3],['abcdefg', 10]]
lst2 = []

for x in range(0, len(lst)):
    lst[x].append(len(lst[x][0]))


lst = sorted(lst, key=itemgetter(2), reverse = True)

lst2 = sorted(lst, key=itemgetter(2), reverse = False)
print lst2

for x in range(0, len(lst)):
    lst[x].pop(2)
print lst
print lst2
#for x in range(0, len(lst2)):
#    lst2[x].pop(2)
#print lst2
"""

#lst = list(tuple)

tuples = sorted(tuples, key=itemgetter(0))
print tuples
tuples = sorted(tuples
"""
