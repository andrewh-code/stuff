#!/usr/bin/python

#import libraries
import sys


"""
Errors:

- preprocess.py --> null value inputted
- preprocess.py --> lenght of string has to be between 1 and 15
- preprocess.py --> only alpha chars and underscores (maximum of 2 underscores) allowed
- preprocess.py --> unable to reorder strings

- Process.StringPermutations --> unable to append string to list
- Process.StringPermutations, Process.collectDictionarySegments --> unable to create set mapping for permutation
- Process.collectDictionarySegments --> unable to open file
- Process.StringPermutations -->
- Process.StringPermutations -->
- Process.StringPermutations -->